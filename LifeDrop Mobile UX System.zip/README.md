# LifeDrop

**Drop it. LifeDrop remembers.**

A personal AI-powered life organizer. Drop a screenshot, bill, receipt, booking or document and LifeDrop extracts the title, merchant, amount, dates, category and reminder, then files it.

## Prototype entry point

Open `LifeDrop.dc.html` — an interactive mobile prototype (390 x 844, responsive 360–430px) with a screen index beside the phone. Open `LifeDrop Brand.dc.html` for the identity, tokens, component library, motion spec and App Store previews.

### Core flow that works end to end
Splash -> Onboarding 1-3 -> Sign In / Create Account -> Permissions -> Home -> Drop menu -> Camera or Upload -> AI Processing -> Review -> Save -> Success -> Item Detail.

Also live: Smart Inbox (filter chips, swipe actions), Calendar (month + agenda), Vault (categories, list/grid), Search (results + empty), Spending, Subscriptions, Notifications, Profile, Settings, Notification preferences, Privacy & Security, Appearance (real light/dark switch), Help, and the Offline / Upload failure / Unreadable / Skeleton / Empty states.

## Structure

    LifeDrop.dc.html          interactive prototype (all screens, motion, dark mode)
    LifeDrop Brand.dc.html    brand sheet, design system, motion spec, marketing previews
    assets/logo/              primary logo, mark, wordmark, white, monochrome
    assets/app-icon/          app icon master (light + dark)
    assets/icons/             21 interface + category icons, one 24px grid
    assets/illustrations/     onboarding, empty, processing, success
    design/brand-guide.md     identity, voice, logo rules
    design/design-system.md   tokens and components
    design/motion-spec.md     motion tokens, per-interaction specs, haptics

## Notes

- Mock data only, no backend. Peso amounts and Philippine merchants throughout.
- Reduced motion is honoured (`prefers-reduced-motion`); processing steps still advance.
- Touch targets are 44px or larger; status is never carried by colour alone (icon + label + text).
- Raster imagery is not used. Where a real photo or screenshot belongs, the prototype draws a labelled document placeholder — see the asset brief in `design/brand-guide.md`.
