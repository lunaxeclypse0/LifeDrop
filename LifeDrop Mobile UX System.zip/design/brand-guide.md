# LifeDrop brand guide

## Idea

CHAOS -> DROP -> ORGANIZED. An unstructured thing falls in as a drop; it ripples, and settles as a structured card. Every brand moment is a frame of that sequence: the splash drop lands and ripples, onboarding shows the fall then the structure, processing scans a floating drop, success settles a card into place.

## Tagline

**Drop it. LifeDrop remembers.** (primary, chosen)

Considered: "Your life, automatically organized." — descriptive but passive. "Drop the clutter. Keep what matters." — good, but the promise is memory, not tidying. The chosen line names the action and the payoff in five words and survives being set at 10px under the mark.

## Voice

Calm, factual, second person. Short sentences. Never cute, never alarmed. Say what happened and what will happen: "Internet Bill from Globe Fiber is in your Inbox. We'll remind you on September 26." Privacy copy states facts only: "Your drops stay private." "Review before saving." "Delete your data anytime." No security claims we cannot support.

## Logo

A drop, filled with the cyan-to-indigo brand gradient, holding three left-aligned bars — the messy thing already turned into structured lines. The shortest bar is cyan: the detail LifeDrop found.

- `lifedrop-logo.svg` — primary lockup, mark + wordmark + tagline
- `lifedrop-mark.svg` — icon-only mark, legible down to 16px
- `lifedrop-wordmark.svg` — wordmark alone (Manrope ExtraBold, -1.1 tracking)
- `lifedrop-logo-white.svg` — for dark and photographic grounds
- `lifedrop-mark-mono.svg` — single-ink version, ink #0F172A
- `app-icon/app-icon-master.svg`, `app-icon-dark.svg` — 512px, 112px corner radius

Rules: clear space equals the width of one bar on all sides. Never rotate, outline, re-colour the bars, or place the gradient mark on a mid-tone colour — use the white version instead. Minimum mark size 16px; below 24px drop the tagline, below 96px lockup width drop the tagline line.

## Colour

Primary #6366F1, secondary #06B6D4, accent #8B5CF6, success #10B981, warning #F59E0B, danger #EF4444, info #3B82F6, dark #0F172A, gray #64748B, light #F8FAFC. The gradient (#22D3EE -> #6366F1 -> #4338CA) belongs to the mark, the primary button and the Life Pulse card. Everywhere else the palette is flat.

## Typography

Manrope ExtraBold for display, titles and numerals; Plus Jakarta Sans for body, labels and controls. Numbers are always Manrope — amounts are the thing people scan for.

## Photography and raster asset brief

The prototype ships no raster images. Two slots want real material later:

1. **Original drop previews** (item detail, review, vault) — the user's own screenshot, rendered at 46x58 and full-bleed on tap. Needs: rounded 9px crop, top-aligned, 2x.
2. **Marketing previews** — three 1290x2796 App Store frames built from real device captures of Home, Smart Inbox and Calendar, over the #F8FAFC-to-#EEF0FE wash used in `LifeDrop Brand.dc.html`.
