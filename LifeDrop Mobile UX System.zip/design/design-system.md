# LifeDrop design system

## Tokens

### Colour (light / dark)

    --background        #F8FAFC / #0B1220
    --surface           #FFFFFF / #111A2E
    --surface-elevated  #FFFFFF / #17223C
    --text-primary      #0F172A / #F8FAFC
    --text-secondary    #475569 / #94A3B8
    --text-muted        #64748B / #64748B
    --border            #E2E8F0 / #243049
    --brand-primary     #6366F1 / #818CF8
    --brand-secondary   #06B6D4 / #22D3EE
    --success           #10B981 / #34D399
    --warning           #F59E0B / #FBBF24
    --danger            #EF4444 / #F87171
    --info              #3B82F6 / #60A5FA

Dark mode is a near-black navy (#0B1220) with two elevation steps, dimmed borders and lifted accents — not an inversion.

Category colours: Bill indigo, Receipt cyan, Booking blue, Subscription violet, Warranty green, Document slate, Event amber. Each is used as a 13px-radius tinted icon tile plus a text label, never as the only signal.

### Spacing

4, 8, 12, 16, 20, 24, 32, 40, 48. Screen gutter 20. Card padding 14–18. Section gap 14–22.

### Radius

small 10, medium 14, card 16–18, sheet 26, pill only for avatars, dots and the Drop button.

### Shadow

    --sh-sm  0 1px 2px rgba(15,23,42,.06)
    --sh-md  0 8px 22px -8px rgba(15,23,42,.16), 0 1px 3px rgba(15,23,42,.05)
    --sh-lg  0 22px 50px -14px rgba(15,23,42,.28)

### Type

    Display        29–30 / 1.16  Manrope 800  -1.0 tracking
    Page title     22–26 / 1.2   Manrope 800  -0.7
    Section label  11    / 1.4   Jakarta 700  +1.6 uppercase
    Card title     15–16 / 1.3   Jakarta 700  -0.2
    Body           14–15 / 1.55  Jakarta 400/600
    Caption        11–12 / 1.45  Jakarta 400/600
    Amount         15–38         Manrope 800  -0.3 to -1.6
    Button         15–16         Jakarta 700

## Components

Buttons — primary (gradient fill, 14px radius, 17px padding, lg shadow), secondary (surface + border), ghost (text only), destructive (danger text on surface), icon (44x44, 13–14px radius).

Inputs — text, search (leading icon + clear), date, currency, dropdown. 15px padding, 14px radius, 1px border; focus is a 1.5px primary border.

Cards — DropCard, BillCard, ReceiptCard, BookingCard, DocumentCard, ReminderCard share one skeleton: tinted category tile, title, sub, meta row (category chip + date), trailing Manrope amount. Type only changes what the meta row carries.

Also: SmartSummary (Life Pulse gradient card and the AI summary strip), CategoryChip, StatusBadge (icon + word), BottomSheet (26px top radius, spring), Modal, Toast (with Undo), NavigationBar (5 tabs, elevated Drop button), FloatingDropButton, SearchBar, CalendarCell (date + category dots), EmptyState, SkeletonCard, NotificationRow, DocumentPreview.

## Accessibility

44px minimum targets. Body text meets 4.5:1 on its ground; white on the gradient primary is held at full opacity. Status is icon + word + colour. Focus is a 2px primary outline at 2px offset. Reduced motion collapses every animation to 1ms and the processing sequence still advances. Longer text truncates with ellipsis rather than reflowing card geometry.
