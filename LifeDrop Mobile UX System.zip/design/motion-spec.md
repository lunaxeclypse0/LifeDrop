# LifeDrop motion spec

## Tokens

    fast       170ms   micro-states, toggles, chips
    standard   230ms   card entrance, page fade
    emphasis   310ms   bottom sheets, success
    large      440ms   full-screen transitions

    ease-out   cubic-bezier(.16,.84,.26,1)   entrances
    ease-in    cubic-bezier(.4,0,1,1)        exits
    spring     cubic-bezier(.2,.9,.24,1)     physical controls
    standard   cubic-bezier(.2,.8,.2,1)      page transitions, width/height

`@media (prefers-reduced-motion: reduce)` collapses all durations to 1ms and stops loops.

## Specifications

**Logo** — drop falls 54px with a 1.06 overshoot (780ms spring), ripple ring expands 0.45 -> 1.9 and fades (1600ms, loops), wordmark fades up 320ms at 620ms. Total 900ms.

**Page transitions** — fade 220ms plus 8–12px translate on content; the scroll position resets on navigation.

**Bottom sheets** — translateY 102% -> 0, 320ms spring. Scrim fades 200ms. Options stagger 40ms each.

**Drop button** — press scale 0.965 over 170ms, release springs to 1. Light haptic.

**Drop menu** — sheet springs up, six options fade + rise 10px staggered 40ms (0–200ms).

**Processing** — card floats +/-4px (3600ms loop), a cyan scan line sweeps 1400ms alternate, ripple rings pulse behind it. Captions advance every 620ms: reading -> finding -> checking -> organizing -> Ready. Extracted rows enter fade + 10px at 260ms as each is found. Progress bar eases width 520ms. Sequence completes in ~2.6s, then auto-advances to Review. If real work ran long, the float and scan loop indefinitely and the caption holds at "Organizing everything…".

**Card entrance** — fade + translateY 10px, 240ms ease-out, 45ms stagger per card, capped at 8.

**Save success** — circle pops in (380ms spring), check strokes on over 520ms via stroke-dashoffset, ripple loops, the saved card settles in at 340ms. Medium haptic.

**Swipe actions** — row translates -112px to reveal Remind and Archive, 240ms standard; a move under 34px snaps back. Archive fires a toast with Undo.

**Pull to refresh** — the drop mark stretches with pull distance, releases into a ripple, then the list re-staggers.

**Empty states** — illustration floats +/-4px over 4200ms; offline icon breathes opacity .5 -> 1 over 3200ms.

**Calendar** — month switches slide horizontally, the grid crossfades 240ms, agenda re-staggers.

**Numbers** — spending total counts up over 900ms with a cubic ease-out.

**Haptics** — light on capture and chip selection, medium on successful save, warning on destructive confirmation.
